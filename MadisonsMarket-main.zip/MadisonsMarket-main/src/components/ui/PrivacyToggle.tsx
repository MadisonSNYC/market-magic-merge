
import React from 'react';
import { cn } from '@/lib/utils';
import { EyeIcon, EyeOffIcon } from 'lucide-react';
import { Toggle } from '@/components/ui/toggle';

interface PrivacyToggleProps {
  isPrivate: boolean;
  onToggle: () => void;
  className?: string;
}

export function PrivacyToggle({ isPrivate, onToggle, className }: PrivacyToggleProps) {
  return (
    <div className={cn("flex items-center gap-2", className)}>
      <Toggle 
        pressed={isPrivate} 
        onPressedChange={onToggle}
        aria-label="Toggle privacy"
        className="data-[state=on]:bg-pink-200 data-[state=on]:text-pink-800 h-8 px-2"
      >
        {isPrivate ? (
          <div className="flex items-center gap-1">
            <EyeOffIcon className="h-3.5 w-3.5" />
            <span className="text-xs font-medium">Hidden</span>
          </div>
        ) : (
          <div className="flex items-center gap-1">
            <EyeIcon className="h-3.5 w-3.5" />
            <span className="text-xs font-medium">Visible</span>
          </div>
        )}
      </Toggle>
    </div>
  );
}
