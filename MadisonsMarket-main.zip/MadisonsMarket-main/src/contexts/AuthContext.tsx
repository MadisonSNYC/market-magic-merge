
// This file is kept for backward compatibility
// New code should import from '@/contexts/auth'
export { AuthProvider, useAuth } from './auth';
