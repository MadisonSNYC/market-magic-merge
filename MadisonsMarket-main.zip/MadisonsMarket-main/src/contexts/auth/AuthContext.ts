
import { createContext } from 'react';
import { User, AuthError, AuthResponse } from '@supabase/supabase-js';

// Define the shape of our authentication context state
export interface AuthContextProps {
  user: User | null;
  loading: boolean;
  error: string | null;
  signIn: (email: string, password: string) => Promise<AuthResponse>;
  signUp: (email: string, password: string) => Promise<AuthResponse>;
  signOut: () => Promise<void>;
  clearError: () => void;
}

// Create the context with a default value
export const AuthContext = createContext<AuthContextProps | undefined>(undefined);
