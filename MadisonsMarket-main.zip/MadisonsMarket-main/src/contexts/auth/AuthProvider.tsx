
"use client";

import React, { useState, useEffect } from 'react';
import { User, AuthError, AuthResponse } from '@supabase/supabase-js';
import { supabase } from '@/integrations/supabase/client';
import { toast } from '@/hooks/use-toast';
import { AuthContext } from './AuthContext';

// Provider component that wraps your app and makes auth object available to any child component
export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);

  // Check for an existing session when the component mounts
  useEffect(() => {
    console.log('AuthProvider: Setting up auth listener');
    
    // Set up auth state listener FIRST
    const { data: { subscription } } = supabase.auth.onAuthStateChange(
      (event, session) => {
        console.log('Auth state changed:', event, session?.user?.email);
        setUser(session?.user || null);
        setLoading(false);
      }
    );

    // THEN check for existing session
    const checkSession = async () => {
      try {
        console.log('AuthProvider: Checking for existing session');
        const { data: { session } } = await supabase.auth.getSession();
        console.log('Existing session check result:', session?.user?.email || 'No session');
        setUser(session?.user || null);
      } catch (err) {
        console.error('Error checking auth session:', err);
        setError('Failed to retrieve authentication session');
      } finally {
        setLoading(false);
      }
    };

    checkSession();

    // Clean up subscription when unmounting
    return () => {
      subscription.unsubscribe();
    };
  }, []);

  // Sign in with email and password
  const signIn = async (email: string, password: string) => {
    try {
      setLoading(true);
      setError(null);
      
      console.log('Attempting to sign in with email:', email);
      const response = await supabase.auth.signInWithPassword({
        email: email,
        password: password
      });
      
      console.log('Sign in response:', response);
      
      if (response.error) {
        setError(response.error.message);
        console.error('Sign in error:', response.error.message);
      } else {
        toast({
          title: "Sign in successful",
          description: `Welcome back, ${email}!`,
        });
      }
      
      return response;
    } catch (err) {
      const authError = err as AuthError;
      console.error('Sign in exception:', authError);
      setError(authError.message || 'Failed to sign in');
      throw err;
    } finally {
      setLoading(false);
    }
  };

  // Sign up with email and password
  const signUp = async (email: string, password: string) => {
    try {
      setLoading(true);
      setError(null);
      
      console.log('Attempting to sign up with email:', email);
      const response = await supabase.auth.signUp({
        email: email,
        password: password,
        options: {
          emailRedirectTo: window.location.origin + '/dashboard'
        }
      });
      
      console.log('Sign up response:', response);
      
      if (response.error) {
        setError(response.error.message);
        console.error('Sign up error:', response.error.message);
      } else {
        toast({
          title: "Sign up successful",
          description: "Please check your email to confirm your account.",
        });
      }
      
      return response;
    } catch (err) {
      const authError = err as AuthError;
      console.error('Sign up exception:', authError);
      setError(authError.message || 'Failed to sign up');
      throw err;
    } finally {
      setLoading(false);
    }
  };

  // Sign out
  const signOut = async () => {
    try {
      setLoading(true);
      setError(null);
      
      console.log('Attempting to sign out');
      const { error } = await supabase.auth.signOut();
      
      if (error) {
        setError(error.message);
        console.error('Sign out error:', error.message);
      } else {
        toast({
          title: "Signed out",
          description: "You have been signed out successfully.",
        });
      }
    } catch (err) {
      const authError = err as AuthError;
      console.error('Sign out exception:', authError);
      setError(authError.message || 'Failed to sign out');
      throw err;
    } finally {
      setLoading(false);
    }
  };

  // Clear any authentication errors
  const clearError = () => {
    setError(null);
  };

  // The value that will be supplied to any consuming components
  const value = {
    user,
    loading,
    error,
    signIn,
    signUp,
    signOut,
    clearError
  };

  return (
    <AuthContext.Provider value={value}>
      {children}
    </AuthContext.Provider>
  );
}
