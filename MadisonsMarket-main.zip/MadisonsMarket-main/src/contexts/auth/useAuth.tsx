
import { useContext } from 'react';
import { AuthContext } from './AuthContext';

// Custom hook to use the auth context
export function useAuth() {
  const context = useContext(AuthContext);
  
  // Check for dev bypass mode
  const isDevBypass = localStorage.getItem('dev_bypass_auth') === 'true';
  
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }

  // If we're in dev bypass mode, provide a more comprehensive mock user
  if (isDevBypass && !context.user) {
    console.log('Using development bypass for authentication');
    
    // Create a more comprehensive mock user object for development
    const mockUser = {
      id: 'dev-bypass-user-id',
      email: 'dev@example.com',
      app_metadata: {
        provider: 'development',
        providers: ['development']
      },
      user_metadata: {
        name: 'Development User',
        avatar_url: null
      },
      aud: 'authenticated',
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString(),
      role: 'authenticated',
      // Additional properties that might be needed by components
      confirmed_at: new Date().toISOString(),
      last_sign_in_at: new Date().toISOString(),
      identities: []
    };
    
    // Return a modified context with the mock user
    return {
      ...context,
      user: mockUser,
      loading: false,
      error: null
    };
  }
  
  return context;
}
