
import React, { createContext, useContext, useState, useEffect } from 'react';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { KalshiPosition, KalshiPortfolioData, KalshiAiRecommendation } from '@/utils/kalshi/types';
import { kalshiApi } from '@/utils/kalshi';
import { useAuth } from '@/contexts/auth';
import { useToast } from '@/hooks/use-toast';
import { supabase } from '@/integrations/supabase/client';
import { Position } from '@/components/kalshi/ActivePositions';
import { transformKalshiPositionsToPositions } from '@/utils/kalshi/transformers';

// Query keys for React Query
export const PORTFOLIO_QUERY_KEYS = {
  positions: ['kalshi', 'positions'],
  portfolio: ['kalshi', 'portfolio'],
  recommendations: ['kalshi', 'recommendations'],
};

// Context interface
interface PortfolioContextType {
  positions: Position[];
  kalshiPositions: KalshiPosition[];
  recommendations: KalshiAiRecommendation[];
  portfolioData: KalshiPortfolioData | null;
  loading: boolean;
  error: string | null;
  authError: boolean;
  refreshPortfolio: () => Promise<void>;
}

// Create context with default values
const PortfolioContext = createContext<PortfolioContextType>({
  positions: [],
  kalshiPositions: [],
  recommendations: [],
  portfolioData: null,
  loading: true,
  error: null,
  authError: false,
  refreshPortfolio: async () => {},
});

// Provider component
export function PortfolioProvider({ children }: { children: React.ReactNode }) {
  const [authError, setAuthError] = useState<boolean>(false);
  const { toast } = useToast();
  const { user } = useAuth();
  const queryClient = useQueryClient();
  const isDevBypass = localStorage.getItem('dev_bypass_auth') === 'true';
  
  // Function to handle position data transformation
  const transformPositions = (data: KalshiPosition[]): Position[] => {
    return transformKalshiPositionsToPositions(data);
  };

  // Query for positions
  const positionsQuery = useQuery({
    queryKey: PORTFOLIO_QUERY_KEYS.positions,
    queryFn: async () => {
      console.log("Fetching positions from Kalshi API...");
      if (isDevBypass) {
        // Mock data for development
        return [
          { marketId: 'BTC-PRICE-7PM', yes: 12, no: 0, value: 12.75 },
          { marketId: 'BTC-PRICE-RANGE', yes: 0, no: 29, value: 22.04 },
          { marketId: 'SILVER-BULLETIN', yes: 37, no: 0, value: 23.59 },
          { marketId: 'ETH-PRICE-5PM', yes: 0, no: 26, value: 15.64 }
        ] as KalshiPosition[];
      }
      
      // Real API call
      const positions = await kalshiApi.getPositions();
      console.log("Positions fetched successfully:", positions);
      return positions;
    },
    enabled: !!user || isDevBypass,
  });

  // Query for portfolio data
  const portfolioQuery = useQuery({
    queryKey: PORTFOLIO_QUERY_KEYS.portfolio,
    queryFn: async () => {
      if (isDevBypass) {
        // Mock data for development
        return {
          availableBalance: 1000.00,
          totalPortfolioValue: 1250.75,
          lastUpdated: new Date().toLocaleString()
        } as KalshiPortfolioData;
      }
      
      // Get portfolio data from Supabase
      const { data: portfolioDbData, error: portfolioError } = await supabase
        .from('portfolio')
        .select('*')
        .eq('user_id', user?.id)
        .maybeSingle();
      
      if (portfolioError) {
        console.error("Error fetching portfolio data:", portfolioError);
        
        if (portfolioError.code === 'PGRST404' || 
            portfolioError.message?.includes('user_not_found') ||
            portfolioError.code === '42501') {
          setAuthError(true);
          throw new Error('Authentication error');
        }
        
        throw portfolioError;
      }
      
      if (portfolioDbData) {
        return {
          availableBalance: parseFloat(portfolioDbData.available_balance.toString()),
          totalPortfolioValue: parseFloat(portfolioDbData.total_portfolio_value.toString()),
          lastUpdated: new Date(portfolioDbData.last_updated).toLocaleString()
        } as KalshiPortfolioData;
      }
      
      return null;
    },
    enabled: !!user || isDevBypass,
  });

  // Query for recommendations
  const recommendationsQuery = useQuery({
    queryKey: PORTFOLIO_QUERY_KEYS.recommendations,
    queryFn: async () => {
      if (isDevBypass) {
        // Mock recommendations for development
        return [
          {
            marketId: 'BTC-PRICE-7PM', 
            recommendation: 'BUY YES',
            reason: 'Bitcoin trending upward',
            contractPrice: 0.31,
            size: 12,
            cost: 3.72,
            potentialProfit: 3.72,
            potentialPayout: 12.00,
            confidence: 0.76,
            category: 'crypto'
          },
          {
            marketId: 'BTC-PRICE-RANGE', 
            recommendation: 'BUY NO',
            reason: 'Bitcoin volatility decreasing',
            contractPrice: 0.57,
            size: 29,
            cost: 16.55,
            potentialProfit: 22.04,
            potentialPayout: 29.00,
            confidence: 0.82,
            category: 'crypto'
          }
        ] as KalshiAiRecommendation[];
      }
      
      // Real API call
      return await kalshiApi.getAiRecommendations();
    },
    enabled: !!user || isDevBypass,
  });

  // Function to manually refresh all portfolio data
  const refreshPortfolio = async () => {
    try {
      await Promise.all([
        queryClient.invalidateQueries({ queryKey: PORTFOLIO_QUERY_KEYS.positions }),
        queryClient.invalidateQueries({ queryKey: PORTFOLIO_QUERY_KEYS.portfolio }),
        queryClient.invalidateQueries({ queryKey: PORTFOLIO_QUERY_KEYS.recommendations })
      ]);
    } catch (error: any) {
      console.error("Error refreshing portfolio data:", error);
      toast({
        title: "Error refreshing data",
        description: "Could not refresh your portfolio data. Please try again later.",
        variant: "destructive" 
      });
    }
  };

  // Determine overall loading state
  const isLoading = positionsQuery.isLoading || 
                    portfolioQuery.isLoading || 
                    recommendationsQuery.isLoading;

  // Determine if there's an error
  const error = positionsQuery.error || portfolioQuery.error || recommendationsQuery.error
    ? "Failed to fetch portfolio data. Please try again later."
    : null;

  // Create the value object for the context
  const value = {
    positions: positionsQuery.data ? transformPositions(positionsQuery.data) : [],
    kalshiPositions: positionsQuery.data || [],
    recommendations: recommendationsQuery.data || [],
    portfolioData: portfolioQuery.data,
    loading: isLoading,
    error,
    authError,
    refreshPortfolio
  };

  return (
    <PortfolioContext.Provider value={value}>
      {children}
    </PortfolioContext.Provider>
  );
}

// Custom hook to use the portfolio context
export function usePortfolio() {
  const context = useContext(PortfolioContext);
  
  if (context === undefined) {
    throw new Error('usePortfolio must be used within a PortfolioProvider');
  }
  
  return context;
}
