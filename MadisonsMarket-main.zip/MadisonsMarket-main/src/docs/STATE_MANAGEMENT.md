
# State Management Patterns

This document outlines the state management patterns used in the application.

## Core Principles

1. **Server State vs UI State**
   - Server state (API data) is managed with React Query
   - UI state is managed with React Context and/or local component state

2. **State Organization**
   - Global state: React Context
   - Server/API data: React Query
   - Component-specific state: useState/useReducer
   - Form state: React Hook Form

## React Query Usage

React Query is used for all server state management:

- Defined query keys are in constants at the top of context files
- Queries are centralized in context providers or custom hooks
- Mutations are used for data updates
- Cache invalidation is handled through the query client

Example query:
```typescript
const positionsQuery = useQuery({
  queryKey: ['kalshi', 'positions'],
  queryFn: () => kalshiApi.getPositions(),
  staleTime: 60000 // 1 minute
});
```

## Context Usage

Context is used for sharing state between components that would otherwise require prop drilling:

- Authentication state
- Portfolio data
- Theme preferences
- Global UI state (modals, toasts, etc.)

Each context should:
- Use a clear naming convention (e.g., `AuthContext`, `PortfolioContext`)
- Provide a custom hook for easy access (e.g., `useAuth()`, `usePortfolio()`)
- Handle loading, error, and data states

## Local Component State

Use local state for:
- UI interaction state (open/closed, active tab, etc.)
- Form input state when not using React Hook Form
- Component-specific temporary state

## Data Flow

1. API calls are centralized in service modules
2. Data is fetched and cached by React Query
3. Components access data via custom hooks or context
4. UI interactions trigger mutations or state updates
5. State changes trigger re-renders

## Best Practices

1. Keep related state together
2. Use appropriate state management for the use case
3. Minimize unnecessary re-renders
4. Prefer composition over prop drilling
5. Document state management decisions
