
import { useState } from 'react';
import { Position } from '@/utils/kalshi/types/portfolio';

export function useActivePositions() {
  const [activePositions] = useState<Position[]>([
    {
      marketId: "BTC-PRICE-1PM",
      marketTitle: "Bitcoin price today at 1pm EDT?",
      contracts: 21,
      avgPrice: 68,
      cost: 14.28,
      currentValue: 18.48,
      potentialPayout: 21.00,
      positionType: "YES",
      timeRemaining: "2h 15m",
      icon: "https://cryptologos.cc/logos/bitcoin-btc-logo.png?v=025",
      yes: 21,
      no: 0,
      value: 18.48
    },
    {
      marketId: "NDX-PRICE-1PM",
      marketTitle: "Nasdaq price today at 1pm EDT?",
      contracts: 16,
      avgPrice: 57,
      cost: 9.12,
      currentValue: 8.96,
      potentialPayout: 16.00,
      positionType: "YES",
      timeRemaining: "2h 30m",
      icon: "https://upload.wikimedia.org/wikipedia/commons/thumb/9/96/Nasdaq_logo.svg/2560px-Nasdaq_logo.svg.png",
      yes: 16,
      no: 0,
      value: 8.96
    },
    {
      marketId: "ETH-PRICE-RANGE-12PM",
      marketTitle: "Ethereum price range today at 12pm EDT?",
      contracts: 9,
      avgPrice: 61,
      cost: 5.64,
      currentValue: 9.00,
      potentialPayout: 9.00,
      positionType: "YES",
      timeRemaining: "1h 45m",
      icon: "https://cryptologos.cc/logos/ethereum-eth-logo.png?v=025",
      yes: 9,
      no: 0,
      value: 9.00
    }
  ]);

  return { activePositions };
}
