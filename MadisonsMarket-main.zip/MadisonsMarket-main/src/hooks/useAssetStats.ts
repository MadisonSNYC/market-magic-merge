
import { useState } from 'react';

interface Asset {
  symbol: string;
  name: string;
  price: number;
  change: number;
  changePercent: number;
}

export function useAssetStats() {
  // For now, we'll use static data but this could be updated to fetch from an API
  const [assets] = useState<Asset[]>([
    {
      symbol: "BTC",
      name: "Bitcoin",
      price: 86732.45,
      change: 425.32,
      changePercent: 0.49,
    },
    {
      symbol: "ETH",
      name: "Ethereum",
      price: 2018.72,
      change: -12.35,
      changePercent: -0.61,
    },
    {
      symbol: "DOGE",
      name: "Dogecoin",
      price: 0.1245,
      change: 0.0078,
      changePercent: 6.68,
    },
    {
      symbol: "SPX",
      name: "S&P 500",
      price: 5731.58,
      change: 1.23,
      changePercent: 0.02,
    },
    {
      symbol: "NDX",
      name: "NASDAQ",
      price: 20087.36,
      change: 7.45,
      changePercent: 0.04,
    }
  ]);

  return { assets };
}
