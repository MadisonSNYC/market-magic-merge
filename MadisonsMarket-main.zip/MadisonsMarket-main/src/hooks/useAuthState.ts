
import { useState, useEffect } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { useAuth } from '@/contexts/auth'; // Updated import
import { LoginFormValues } from '@/components/auth/LoginForm';
import { toast } from '@/hooks/use-toast';

export const useAuthState = () => {
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [showTroubleshootDialog, setShowTroubleshootDialog] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [authMode, setAuthMode] = useState<'login' | 'register'>('login');
  
  const navigate = useNavigate();
  const location = useLocation();
  const { signIn, signUp, error, clearError } = useAuth();
  
  const from = (location.state as { from?: { pathname: string } })?.from?.pathname || '/dashboard';
  
  useEffect(() => {
    clearError();
    setErrorMessage(null);
    
    const urlParams = new URLSearchParams(window.location.search);
    const error = urlParams.get('error');
    const errorDescription = urlParams.get('error_description');
    
    if (error || errorDescription) {
      const formattedError = errorDescription || error || 'Authentication failed';
      setErrorMessage(`Login failed: ${formattedError}`);
      console.error('Auth error from URL parameters:', formattedError);
    }
  }, [clearError, location.pathname]);
  
  useEffect(() => {
    if (error) {
      setErrorMessage(error);
    }
  }, [error]);
  
  const handleGoogleLoginStart = () => {
    setErrorMessage(null);
  };
  
  const handleGoogleLoginError = (error: string) => {
    setErrorMessage(error);
  };
  
  const handleTryAgain = () => {
    setErrorMessage(null);
    setShowTroubleshootDialog(false);
  };
  
  const onSubmit = async (data: LoginFormValues) => {
    try {
      setIsSubmitting(true);
      setErrorMessage(null);
      
      const { email, password } = data;
      
      if (authMode === 'login') {
        const response = await signIn(email, password);
        
        if (response.error) {
          setErrorMessage(response.error.message);
        } else {
          toast({
            title: "Login successful",
            description: "Welcome back!",
          });
          navigate(from, { replace: true });
        }
      } else {
        const response = await signUp(email, password);
        
        if (response.error) {
          setErrorMessage(response.error.message);
        } else {
          // Check if email confirmation is required
          if (response.data.user && response.data.user.identities?.length === 0) {
            setErrorMessage("Registration successful! Please check your email for verification.");
            toast({
              title: "Sign up successful",
              description: "Please check your email to confirm your account.",
            });
          } else {
            toast({
              title: "Sign up successful",
              description: "Your account has been created successfully.",
            });
            navigate(from, { replace: true });
          }
        }
      }
    } catch (error: any) {
      console.error('Authentication error:', error);
      setErrorMessage(error.message || 'Authentication failed. Please try again.');
    } finally {
      setIsSubmitting(false);
    }
  };
  
  const toggleAuthMode = () => {
    setAuthMode(prevMode => prevMode === 'login' ? 'register' : 'login');
    setErrorMessage(null);
  };

  return {
    errorMessage,
    showTroubleshootDialog,
    setShowTroubleshootDialog,
    isSubmitting,
    authMode,
    from,
    handleGoogleLoginStart,
    handleGoogleLoginError,
    handleTryAgain,
    onSubmit,
    toggleAuthMode
  };
};
