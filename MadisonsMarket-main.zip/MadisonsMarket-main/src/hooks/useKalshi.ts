import { useState, useEffect } from 'react';
import { KalshiService } from '../services/kalshiService';
import { ApiMarket, ApiPosition, ApiOrder } from '../utils/kalshi';

// Create a service instance
const kalshiService = new KalshiService(import.meta.env.VITE_KALSHI_API_KEY);

// Hook for fetching markets
export function useMarkets(params?: Record<string, any>) {
  const [markets, setMarkets] = useState<ApiMarket[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<Error | null>(null);

  useEffect(() => {
    const fetchMarkets = async () => {
      try {
        setLoading(true);
        const data = await kalshiService.getMarkets(params);
        setMarkets(data);
        setError(null);
      } catch (err) {
        setError(err instanceof Error ? err : new Error('Failed to fetch markets'));
      } finally {
        setLoading(false);
      }
    };

    fetchMarkets();
  }, [JSON.stringify(params)]); // Re-fetch when params change

  return { markets, loading, error };
}

// Hook for fetching a single market
export function useMarket(ticker: string) {
  const [market, setMarket] = useState<ApiMarket | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<Error | null>(null);

  useEffect(() => {
    const fetchMarket = async () => {
      if (!ticker) {
        setMarket(null);
        setLoading(false);
        return;
      }

      try {
        setLoading(true);
        const data = await kalshiService.getMarketByTicker(ticker);
        setMarket(data);
        setError(null);
      } catch (err) {
        setError(err instanceof Error ? err : new Error(`Failed to fetch market ${ticker}`));
      } finally {
        setLoading(false);
      }
    };

    fetchMarket();
  }, [ticker]);

  return { market, loading, error };
}

// Hook for fetching positions
export function usePositions() {
  const [positions, setPositions] = useState<ApiPosition[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<Error | null>(null);

  useEffect(() => {
    const fetchPositions = async () => {
      try {
        setLoading(true);
        const data = await kalshiService.getPositions();
        setPositions(data);
        setError(null);
      } catch (err) {
        setError(err instanceof Error ? err : new Error('Failed to fetch positions'));
      } finally {
        setLoading(false);
      }
    };

    fetchPositions();
  }, []);

  return { positions, loading, error };
}

// Hook for fetching orders
export function useOrders(params?: Record<string, any>) {
  const [orders, setOrders] = useState<ApiOrder[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<Error | null>(null);

  useEffect(() => {
    const fetchOrders = async () => {
      try {
        setLoading(true);
        const data = await kalshiService.getOrders(params);
        setOrders(data);
        setError(null);
      } catch (err) {
        setError(err instanceof Error ? err : new Error('Failed to fetch orders'));
      } finally {
        setLoading(false);
      }
    };

    fetchOrders();
  }, [JSON.stringify(params)]);

  return { orders, loading, error };
}

// Hook for placing an order
export function usePlaceOrder() {
  const [orderId, setOrderId] = useState<string | undefined>(undefined);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<Error | null>(null);
  const [success, setSuccess] = useState(false);

  const placeOrder = async (order: {
    ticker: string;
    side: 'yes' | 'no';
    count: number;
    type: 'limit' | 'market';
    price?: number;
    client_order_id?: string;
  }) => {
    try {
      setLoading(true);
      setSuccess(false);
      setError(null);
      
      const result = await kalshiService.placeOrder(order);
      
      if (result.success) {
        setOrderId(result.orderId);
        setSuccess(true);
      } else {
        throw new Error('Failed to place order');
      }
    } catch (err) {
      setError(err instanceof Error ? err : new Error('Failed to place order'));
      setSuccess(false);
    } finally {
      setLoading(false);
    }
  };

  return { placeOrder, orderId, loading, error, success };
}

// Hook for canceling an order
export function useCancelOrder() {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<Error | null>(null);
  const [success, setSuccess] = useState(false);

  const cancelOrder = async (orderId: string) => {
    try {
      setLoading(true);
      setSuccess(false);
      setError(null);
      
      const result = await kalshiService.cancelOrder(orderId);
      
      if (result) {
        setSuccess(true);
      } else {
        throw new Error(`Failed to cancel order ${orderId}`);
      }
    } catch (err) {
      setError(err instanceof Error ? err : new Error(`Failed to cancel order ${orderId}`));
      setSuccess(false);
    } finally {
      setLoading(false);
    }
  };

  return { cancelOrder, loading, error, success };
}

// Hook for fetching portfolio
export function usePortfolio() {
  const [portfolio, setPortfolio] = useState<{
    available_balance_cents: number;
    portfolio_value_cents: number;
    total_value_cents: number;
    user_id: string;
  } | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<Error | null>(null);

  useEffect(() => {
    const fetchPortfolio = async () => {
      try {
        setLoading(true);
        const data = await kalshiService.getPortfolio();
        setPortfolio(data);
        setError(null);
      } catch (err) {
        setError(err instanceof Error ? err : new Error('Failed to fetch portfolio'));
      } finally {
        setLoading(false);
      }
    };

    fetchPortfolio();
  }, []);

  return { portfolio, loading, error };
}

// Hook for fetching exchange status
export function useExchangeStatus() {
  const [status, setStatus] = useState<{
    is_open: boolean;
    next_open_time: string;
    next_close_time: string;
  } | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<Error | null>(null);

  useEffect(() => {
    const fetchStatus = async () => {
      try {
        setLoading(true);
        const data = await kalshiService.getExchangeStatus();
        setStatus(data);
        setError(null);
      } catch (err) {
        setError(err instanceof Error ? err : new Error('Failed to fetch exchange status'));
      } finally {
        setLoading(false);
      }
    };

    fetchStatus();
  }, []);

  return { status, loading, error };
}
