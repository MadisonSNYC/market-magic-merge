
import { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { kalshiApi } from '@/utils/kalshi';
import { useToast } from '@/hooks/use-toast';

/**
 * A hook for interacting with the Kalshi API
 * Centralizes error handling and loading states
 */
export function useKalshiApi() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [isApiReady, setIsApiReady] = useState(true);
  
  // Check API status
  const apiStatus = useQuery({
    queryKey: ['kalshi', 'api', 'status'],
    queryFn: async () => {
      try {
        const status = await kalshiApi.getExchangeStatus();
        setIsApiReady(status && status.status === 'operational');
        return status;
      } catch (error) {
        console.error('Error checking Kalshi API status:', error);
        setIsApiReady(false);
        throw error;
      }
    },
    refetchInterval: 300000, // Check every 5 minutes
    retry: 2,
  });
  
  // Generic query factory function with error handling
  const createKalshiQuery = <T,>(
    queryKey: string[], 
    apiFn: () => Promise<T>,
    options = {}
  ) => {
    return useQuery({
      queryKey: ['kalshi', ...queryKey],
      queryFn: async () => {
        try {
          return await apiFn();
        } catch (error: any) {
          console.error(`Kalshi API error (${queryKey.join('/')}):`, error);
          toast({
            title: 'API Error',
            description: error.message || 'Failed to fetch data from Kalshi API',
            variant: 'destructive',
          });
          throw error;
        }
      },
      enabled: isApiReady,
      ...options,
    });
  };
  
  // Generic mutation factory with error handling
  const createKalshiMutation = <T, V>(
    mutationFn: (variables: V) => Promise<T>,
    options: any = {}
  ) => {
    return useMutation({
      mutationFn: async (variables: V) => {
        try {
          return await mutationFn(variables);
        } catch (error: any) {
          console.error('Kalshi API mutation error:', error);
          toast({
            title: 'API Error',
            description: error.message || 'Failed to update data on Kalshi API',
            variant: 'destructive',
          });
          throw error;
        }
      },
      ...options,
    });
  };
  
  // Invalidate specific kalshi queries
  const invalidateKalshiQueries = async (queryKeySuffix: string[]) => {
    await queryClient.invalidateQueries({ 
      queryKey: ['kalshi', ...queryKeySuffix] 
    });
  };
  
  return {
    isApiReady,
    apiStatus: apiStatus.data,
    apiStatusLoading: apiStatus.isLoading,
    apiStatusError: apiStatus.error,
    createKalshiQuery,
    createKalshiMutation,
    invalidateKalshiQueries,
  };
}
