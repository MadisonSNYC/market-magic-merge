
import { useState, useEffect } from 'react';
import { KalshiPosition } from '@/utils/kalshi/types';
import { useKalshiPositionsQuery } from './useKalshiPositionsQuery';

export function useKalshiPositions() {
  const [positions, setPositions] = useState<KalshiPosition[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  
  // Use the centralized query hook
  const query = useKalshiPositionsQuery();
  
  useEffect(() => {
    if (query.isLoading) {
      setLoading(true);
    } else if (query.isError) {
      setLoading(false);
      setError("Failed to fetch positions");
      console.error("Error fetching positions:", query.error);
    } else if (query.data) {
      setPositions(query.data);
      setLoading(false);
      setError(null);
    }
  }, [query.isLoading, query.isError, query.data, query.error]);

  return { positions, loading, error };
}
