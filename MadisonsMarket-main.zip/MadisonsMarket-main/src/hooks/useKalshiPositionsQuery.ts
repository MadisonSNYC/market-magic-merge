
import { useQuery } from '@tanstack/react-query';
import { KalshiPosition } from '@/utils/kalshi/types';
import { kalshiApi } from '@/utils/kalshi';

export const POSITIONS_QUERY_KEY = ['kalshi', 'positions'];

/**
 * A centralized hook for fetching Kalshi positions
 * Uses react-query for automatic caching and stale data management
 */
export function useKalshiPositionsQuery() {
  return useQuery({
    queryKey: POSITIONS_QUERY_KEY,
    queryFn: async () => {
      console.log("Fetching positions from Kalshi API (centralized)...");
      const positions = await kalshiApi.getPositions();
      console.log("Positions fetched successfully (centralized):", positions);
      return positions;
    },
    staleTime: 60000, // Consider data fresh for 1 minute
    gcTime: 300000,   // Keep unused data in cache for 5 minutes
  });
}
