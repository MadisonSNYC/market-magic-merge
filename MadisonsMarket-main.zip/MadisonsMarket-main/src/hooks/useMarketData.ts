
import { useState, useEffect } from 'react';
import { kalshiApi } from '@/utils/kalshi';

export interface MarketIndex {
  symbol: string;
  name: string;
  price: number;
  change: number;
  changePercent: number;
}

export function useMarketData() {
  const [indices, setIndices] = useState<MarketIndex[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    // For now we're using the mock indices but this could be updated
    // to fetch from the Kalshi API when ready
    const mockIndices = [
      {
        symbol: "SPX",
        name: "S&P 500",
        price: 5731.58,
        change: 1.23,
        changePercent: 0.02
      },
      {
        symbol: "NDX",
        name: "NASDAQ",
        price: 20087.36,
        change: 7.45,
        changePercent: 0.04
      },
      {
        symbol: "DJI",
        name: "Dow Jones",
        price: 38996.38,
        change: -56.68,
        changePercent: -0.15
      }
    ];
    
    setIndices(mockIndices);
    setLoading(false);
  }, []);

  return { indices, loading, error };
}
