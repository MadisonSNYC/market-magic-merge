export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  public: {
    Tables: {
      assets: {
        Row: {
          amount: number
          buy_date: string | null
          buy_price: number
          created_at: string | null
          current_price: number
          id: string
          name: string
          symbol: string
          user_id: string
        }
        Insert: {
          amount: number
          buy_date?: string | null
          buy_price: number
          created_at?: string | null
          current_price: number
          id: string
          name: string
          symbol: string
          user_id: string
        }
        Update: {
          amount?: number
          buy_date?: string | null
          buy_price?: number
          created_at?: string | null
          current_price?: number
          id?: string
          name?: string
          symbol?: string
          user_id?: string
        }
        Relationships: []
      }
      mantrade_portfolio: {
        Row: {
          asset_symbol: string
          asset_type: string
          created_at: string | null
          id: string
          is_active: boolean | null
          notes: string | null
          purchase_date: string | null
          purchase_price: number
          quantity: number
          stop_loss: number | null
          target_price: number | null
          trade_strategy: string | null
          updated_at: string | null
          user_id: string
        }
        Insert: {
          asset_symbol: string
          asset_type: string
          created_at?: string | null
          id?: string
          is_active?: boolean | null
          notes?: string | null
          purchase_date?: string | null
          purchase_price: number
          quantity: number
          stop_loss?: number | null
          target_price?: number | null
          trade_strategy?: string | null
          updated_at?: string | null
          user_id: string
        }
        Update: {
          asset_symbol?: string
          asset_type?: string
          created_at?: string | null
          id?: string
          is_active?: boolean | null
          notes?: string | null
          purchase_date?: string | null
          purchase_price?: number
          quantity?: number
          stop_loss?: number | null
          target_price?: number | null
          trade_strategy?: string | null
          updated_at?: string | null
          user_id?: string
        }
        Relationships: []
      }
      market_data: {
        Row: {
          additional_data: Json | null
          close_price: number | null
          data_id: number
          high_price: number | null
          low_price: number | null
          market_id: string | null
          open_price: number | null
          timestamp: string
          volume: number | null
        }
        Insert: {
          additional_data?: Json | null
          close_price?: number | null
          data_id?: number
          high_price?: number | null
          low_price?: number | null
          market_id?: string | null
          open_price?: number | null
          timestamp: string
          volume?: number | null
        }
        Update: {
          additional_data?: Json | null
          close_price?: number | null
          data_id?: number
          high_price?: number | null
          low_price?: number | null
          market_id?: string | null
          open_price?: number | null
          timestamp?: string
          volume?: number | null
        }
        Relationships: [
          {
            foreignKeyName: "market_data_market_id_fkey"
            columns: ["market_id"]
            isOneToOne: false
            referencedRelation: "markets"
            referencedColumns: ["market_id"]
          },
        ]
      }
      markets: {
        Row: {
          category: string | null
          description: string | null
          last_updated: string | null
          market_id: string
          market_metadata: Json | null
          name: string
          platform: string
        }
        Insert: {
          category?: string | null
          description?: string | null
          last_updated?: string | null
          market_id: string
          market_metadata?: Json | null
          name: string
          platform: string
        }
        Update: {
          category?: string | null
          description?: string | null
          last_updated?: string | null
          market_id?: string
          market_metadata?: Json | null
          name?: string
          platform?: string
        }
        Relationships: []
      }
      portfolio: {
        Row: {
          available_balance: number
          created_at: string
          id: string
          last_updated: string
          total_portfolio_value: number
          user_id: string
        }
        Insert: {
          available_balance?: number
          created_at?: string
          id?: string
          last_updated?: string
          total_portfolio_value?: number
          user_id: string
        }
        Update: {
          available_balance?: number
          created_at?: string
          id?: string
          last_updated?: string
          total_portfolio_value?: number
          user_id?: string
        }
        Relationships: []
      }
      profiles: {
        Row: {
          business_hours: string | null
          business_name: string | null
          business_type: string | null
          contact_email: string | null
          contact_phone: string | null
          created_at: string | null
          first_name: string | null
          id: string
          is_admin: boolean
          last_name: string | null
          updated_at: string | null
        }
        Insert: {
          business_hours?: string | null
          business_name?: string | null
          business_type?: string | null
          contact_email?: string | null
          contact_phone?: string | null
          created_at?: string | null
          first_name?: string | null
          id: string
          is_admin?: boolean
          last_name?: string | null
          updated_at?: string | null
        }
        Update: {
          business_hours?: string | null
          business_name?: string | null
          business_type?: string | null
          contact_email?: string | null
          contact_phone?: string | null
          created_at?: string | null
          first_name?: string | null
          id?: string
          is_admin?: boolean
          last_name?: string | null
          updated_at?: string | null
        }
        Relationships: []
      }
      recommendations: {
        Row: {
          action: string
          confidence: number
          created_at: string | null
          expires_at: string | null
          is_executed: boolean | null
          market_id: string | null
          price: number
          reasons: Json | null
          recommendation_id: number
          strategy_id: number | null
        }
        Insert: {
          action: string
          confidence: number
          created_at?: string | null
          expires_at?: string | null
          is_executed?: boolean | null
          market_id?: string | null
          price: number
          reasons?: Json | null
          recommendation_id?: number
          strategy_id?: number | null
        }
        Update: {
          action?: string
          confidence?: number
          created_at?: string | null
          expires_at?: string | null
          is_executed?: boolean | null
          market_id?: string | null
          price?: number
          reasons?: Json | null
          recommendation_id?: number
          strategy_id?: number | null
        }
        Relationships: [
          {
            foreignKeyName: "recommendations_market_id_fkey"
            columns: ["market_id"]
            isOneToOne: false
            referencedRelation: "markets"
            referencedColumns: ["market_id"]
          },
          {
            foreignKeyName: "recommendations_strategy_id_fkey"
            columns: ["strategy_id"]
            isOneToOne: false
            referencedRelation: "strategies"
            referencedColumns: ["strategy_id"]
          },
        ]
      }
      sentiment_data: {
        Row: {
          confidence: number
          created_at: string | null
          market_id: string | null
          processed_keywords: Json | null
          raw_text: string | null
          sentiment_id: number
          sentiment_score: number
          source: string
          timestamp: string
        }
        Insert: {
          confidence: number
          created_at?: string | null
          market_id?: string | null
          processed_keywords?: Json | null
          raw_text?: string | null
          sentiment_id?: number
          sentiment_score: number
          source: string
          timestamp: string
        }
        Update: {
          confidence?: number
          created_at?: string | null
          market_id?: string | null
          processed_keywords?: Json | null
          raw_text?: string | null
          sentiment_id?: number
          sentiment_score?: number
          source?: string
          timestamp?: string
        }
        Relationships: [
          {
            foreignKeyName: "sentiment_data_market_id_fkey"
            columns: ["market_id"]
            isOneToOne: false
            referencedRelation: "markets"
            referencedColumns: ["market_id"]
          },
        ]
      }
      strategies: {
        Row: {
          created_at: string | null
          description: string | null
          entry_conditions: Json
          exit_conditions: Json
          is_active: boolean | null
          market_type: string
          name: string
          risk_tolerance: number
          strategy_id: number
          updated_at: string | null
        }
        Insert: {
          created_at?: string | null
          description?: string | null
          entry_conditions: Json
          exit_conditions: Json
          is_active?: boolean | null
          market_type: string
          name: string
          risk_tolerance: number
          strategy_id?: number
          updated_at?: string | null
        }
        Update: {
          created_at?: string | null
          description?: string | null
          entry_conditions?: Json
          exit_conditions?: Json
          is_active?: boolean | null
          market_type?: string
          name?: string
          risk_tolerance?: number
          strategy_id?: number
          updated_at?: string | null
        }
        Relationships: []
      }
      trades: {
        Row: {
          created_at: string | null
          entry_price: number
          entry_time: string
          exit_price: number | null
          exit_time: string | null
          market_id: string | null
          notes: string | null
          pnl: number | null
          position_size: number
          status: string
          strategy_id: number | null
          trade_id: number
          trade_metadata: Json | null
          updated_at: string | null
        }
        Insert: {
          created_at?: string | null
          entry_price: number
          entry_time: string
          exit_price?: number | null
          exit_time?: string | null
          market_id?: string | null
          notes?: string | null
          pnl?: number | null
          position_size: number
          status?: string
          strategy_id?: number | null
          trade_id?: number
          trade_metadata?: Json | null
          updated_at?: string | null
        }
        Update: {
          created_at?: string | null
          entry_price?: number
          entry_time?: string
          exit_price?: number | null
          exit_time?: string | null
          market_id?: string | null
          notes?: string | null
          pnl?: number | null
          position_size?: number
          status?: string
          strategy_id?: number | null
          trade_id?: number
          trade_metadata?: Json | null
          updated_at?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "trades_market_id_fkey"
            columns: ["market_id"]
            isOneToOne: false
            referencedRelation: "markets"
            referencedColumns: ["market_id"]
          },
          {
            foreignKeyName: "trades_strategy_id_fkey"
            columns: ["strategy_id"]
            isOneToOne: false
            referencedRelation: "strategies"
            referencedColumns: ["strategy_id"]
          },
        ]
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      [_ in never]: never
    }
    Enums: {
      [_ in never]: never
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type PublicSchema = Database[Extract<keyof Database, "public">]

export type Tables<
  PublicTableNameOrOptions extends
    | keyof (PublicSchema["Tables"] & PublicSchema["Views"])
    | { schema: keyof Database },
  TableName extends PublicTableNameOrOptions extends { schema: keyof Database }
    ? keyof (Database[PublicTableNameOrOptions["schema"]]["Tables"] &
        Database[PublicTableNameOrOptions["schema"]]["Views"])
    : never = never,
> = PublicTableNameOrOptions extends { schema: keyof Database }
  ? (Database[PublicTableNameOrOptions["schema"]]["Tables"] &
      Database[PublicTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : PublicTableNameOrOptions extends keyof (PublicSchema["Tables"] &
        PublicSchema["Views"])
    ? (PublicSchema["Tables"] &
        PublicSchema["Views"])[PublicTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  PublicTableNameOrOptions extends
    | keyof PublicSchema["Tables"]
    | { schema: keyof Database },
  TableName extends PublicTableNameOrOptions extends { schema: keyof Database }
    ? keyof Database[PublicTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = PublicTableNameOrOptions extends { schema: keyof Database }
  ? Database[PublicTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : PublicTableNameOrOptions extends keyof PublicSchema["Tables"]
    ? PublicSchema["Tables"][PublicTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  PublicTableNameOrOptions extends
    | keyof PublicSchema["Tables"]
    | { schema: keyof Database },
  TableName extends PublicTableNameOrOptions extends { schema: keyof Database }
    ? keyof Database[PublicTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = PublicTableNameOrOptions extends { schema: keyof Database }
  ? Database[PublicTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : PublicTableNameOrOptions extends keyof PublicSchema["Tables"]
    ? PublicSchema["Tables"][PublicTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  PublicEnumNameOrOptions extends
    | keyof PublicSchema["Enums"]
    | { schema: keyof Database },
  EnumName extends PublicEnumNameOrOptions extends { schema: keyof Database }
    ? keyof Database[PublicEnumNameOrOptions["schema"]]["Enums"]
    : never = never,
> = PublicEnumNameOrOptions extends { schema: keyof Database }
  ? Database[PublicEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : PublicEnumNameOrOptions extends keyof PublicSchema["Enums"]
    ? PublicSchema["Enums"][PublicEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof PublicSchema["CompositeTypes"]
    | { schema: keyof Database },
  CompositeTypeName extends PublicCompositeTypeNameOrOptions extends {
    schema: keyof Database
  }
    ? keyof Database[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never = never,
> = PublicCompositeTypeNameOrOptions extends { schema: keyof Database }
  ? Database[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof PublicSchema["CompositeTypes"]
    ? PublicSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never
