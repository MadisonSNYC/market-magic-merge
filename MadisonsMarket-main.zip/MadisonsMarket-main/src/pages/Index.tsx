
import React from 'react';
import { Dashboard } from '@/components/layout/Dashboard';
import { AiRecommendedTrades } from '@/components/dashboard/AiRecommendedTrades';

const Index = () => {
  return (
    <div className="container mx-auto">
      <Dashboard />
    </div>
  );
};

export default Index;
