
// Re-export all API modules
import { KalshiApiClient } from './apiClient';
import { RATE_LIMIT_TIERS } from '../client/coreClient';
import type { RateLimitUsage } from '../client/rateLimiter';
import { API_KEY, AUTH_METHOD, RSA_KEY_ID, RSA_PRIVATE_KEY } from '../config';
import type { RsaAuthOptions } from '../client/auth/rsaAuth';

// Export factory and main client
export { 
  KalshiApiClient, 
  RATE_LIMIT_TIERS 
};

// Create and export a singleton instance of the API client for use throughout the app
let rsaOptions: RsaAuthOptions | undefined;

if (AUTH_METHOD === 'rsa' && RSA_KEY_ID && RSA_PRIVATE_KEY) {
  rsaOptions = {
    keyId: RSA_KEY_ID,
    privateKey: RSA_PRIVATE_KEY
  };
}

export const kalshiApi = new KalshiApiClient(API_KEY, rsaOptions);

// Set up rate limit warning event listener
if (typeof window !== 'undefined') {
  window.addEventListener('kalshi-rate-limit-warning', (event: any) => {
    console.warn('Kalshi API rate limit warning:', event.detail);
    
    // You can display a toast or other notification here
    const warningEvent = new CustomEvent('show-toast', {
      detail: {
        title: `${event.detail.type.toUpperCase()} Rate Limit Warning`,
        description: `You are at ${event.detail.percentage.toFixed(0)}% of your hourly ${event.detail.type} rate limit (${event.detail.current}/${event.detail.limit})`,
        variant: "warning"
      }
    });
    window.dispatchEvent(warningEvent);
  });
}

// Export types
export type { RateLimitUsage };
