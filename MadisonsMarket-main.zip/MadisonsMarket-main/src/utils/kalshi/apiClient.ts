import { RATE_LIMIT_TIERS, RateLimitTier } from './client/coreClient';
import { createDomainApiClients } from './api/factory';
import { 
  MarketApiWrapper,
  UserApiWrapper,
  MetaApiWrapper,
  TradingApiWrapper,
  EventApiWrapper,
  CollectionApiWrapper,
  StructuredTargetApiWrapper,
  RateLimitApiWrapper
} from './api/clients';
import type { RateLimitUsage } from './api/clients/rateLimitApiWrapper';
import { RsaAuthOptions } from './client/auth/rsaAuth';

/**
 * Main Kalshi API client
 */
export class KalshiApiClient {
  private clients: ReturnType<typeof createDomainApiClients>;
  private marketWrapper: MarketApiWrapper;
  private userWrapper: UserApiWrapper;
  private metaWrapper: MetaApiWrapper;
  private tradingWrapper: TradingApiWrapper;
  private eventWrapper: EventApiWrapper;
  private collectionWrapper: CollectionApiWrapper;
  private structuredTargetWrapper: StructuredTargetApiWrapper;
  private rateLimitWrapper: RateLimitApiWrapper;
  
  constructor(apiKey?: string, rsaOptions?: RsaAuthOptions, tier?: RateLimitTier) {
    // Initialize all domain-specific clients
    this.clients = createDomainApiClients(apiKey, rsaOptions);
    
    // Create wrapper instances - pass any type since we know the implementation is correct
    this.marketWrapper = new MarketApiWrapper(this.clients.marketClient as any);
    this.userWrapper = new UserApiWrapper(this.clients.userClient as any);
    this.metaWrapper = new MetaApiWrapper(this.clients.metaClient as any);
    this.tradingWrapper = new TradingApiWrapper(this.clients.tradeClient as any);
    this.eventWrapper = new EventApiWrapper(this.clients.eventClient as any);
    this.collectionWrapper = new CollectionApiWrapper(this.clients.collectionClient as any);
    this.structuredTargetWrapper = new StructuredTargetApiWrapper(this.clients.structuredTargetClient as any);
    
    // Initialize rate limit wrapper
    this.rateLimitWrapper = new RateLimitApiWrapper();
    
    // Set the tier if provided
    if (tier) {
      this.setTier(tier);
    }
  }
  
  // Rate limiting functionality
  setTier(tier: RateLimitTier): void {
    this.rateLimitWrapper.setTier(tier);
  }
  
  getTier(): RateLimitTier {
    return this.rateLimitWrapper.getTier();
  }
  
  onUsageUpdate(callback: (usage: RateLimitUsage) => void): void {
    this.rateLimitWrapper.onUsageUpdate(callback);
  }
  
  getCurrentUsage(): RateLimitUsage {
    return this.rateLimitWrapper.getCurrentUsage();
  }
  
  // Market methods
  getMarkets(params?: any) { return this.marketWrapper.getMarkets(params); }
  getMarketById(id: string) { return this.marketWrapper.getMarketById(id); }
  getMarketsByEvent(eventTicker: string) { return this.marketWrapper.getMarketsByEvent(eventTicker); }
  getMarketsBySeries(seriesTicker: string) { return this.marketWrapper.getMarketsBySeries(seriesTicker); }
  getMarket(ticker: string) { return this.marketWrapper.getMarket(ticker); }
  getMarketOrderbook(ticker: string, depth?: number) { return this.marketWrapper.getMarketOrderbook(ticker, depth); }
  getMarketCandlesticks(seriesTicker: string, ticker: string, params: any) {
    return this.marketWrapper.getMarketCandlesticks(seriesTicker, ticker, params);
  }
  
  // User methods
  getPositions() { return this.userWrapper.getPositions(); }
  placeOrder(order: any) { return this.userWrapper.placeOrder(order); }
  getPortfolio() { return this.userWrapper.getPortfolio(); }
  getAiRecommendations() { return this.userWrapper.getAiRecommendations(); }
  getBalance() { return this.userWrapper.getBalance(); }
  getFills(params?: any) { return this.userWrapper.getFills(params); }
  getOrders(params?: any) { return this.userWrapper.getOrders(params); }
  createOrder(order: any) { return this.userWrapper.createOrder(order); }
  batchCreateOrders(batchRequest: any) { return this.userWrapper.batchCreateOrders(batchRequest); }
  batchCancelOrders(batchRequest: any) { return this.userWrapper.batchCancelOrders(batchRequest); }
  getOrder(orderId: string) { return this.userWrapper.getOrder(orderId); }
  cancelOrder(orderId: string) { return this.userWrapper.cancelOrder(orderId); }
  amendOrder(orderId: string, amendRequest: any) { return this.userWrapper.amendOrder(orderId, amendRequest); }
  
  // Meta methods
  getApiVersion() { 
    const versionResponse = this.metaWrapper.getApiVersion();
    return versionResponse?.version || 'unknown';
  }
  getCommunicationsId() { return this.metaWrapper.getCommunicationsId(); }
  getExchangeAnnouncements() { return this.metaWrapper.getExchangeAnnouncements(); }
  getExchangeSchedule() { return this.metaWrapper.getExchangeSchedule(); }
  getExchangeStatus() { return this.metaWrapper.getExchangeStatus(); }
  getMilestones(params?: any) { return this.metaWrapper.getMilestones(params); }
  getMilestoneById(milestoneId: string) { return this.metaWrapper.getMilestoneById(milestoneId); }
  
  // Trading methods
  getTradeHistory(params?: any) { return this.tradingWrapper.getTradeHistory(params); }
  getTrade(params: any) { return this.tradingWrapper.getTrade(params); }
  getTradeOrders(params?: any) { return this.tradingWrapper.getTradeOrders(params); }
  getTradeOrder(params: any) { return this.tradingWrapper.getTradeOrder(params); }
  getTradeOrderbook(params?: any) { return this.tradingWrapper.getTradeOrderbook(params); }
  getTradeCandlesticks(params?: any) { return this.tradingWrapper.getTradeCandlesticks(params); }
  getTradeFills(params?: any) { return this.tradingWrapper.getTradeFills(params); }
  getTradeOrdersByTradeId(tradeId: string, params?: any) { return this.tradingWrapper.getTradeOrdersByTradeId(tradeId, params); }
  getTradeOrderbookByTradeId(tradeId: string, params?: any) { return this.tradingWrapper.getTradeOrderbookByTradeId(tradeId, params); }
  getTradeCandlesticksByTradeId(tradeId: string, params?: any) { return this.tradingWrapper.getTradeCandlesticksByTradeId(tradeId, params); }
  getTradeFillsByTradeId(tradeId: string, params?: any) { return this.tradingWrapper.getTradeFillsByTradeId(tradeId, params); }
  
  // Event methods
  getEvent(params?: any) { return this.eventWrapper.getEvent(params); }
  getEventMarkets(params?: any) { return this.eventWrapper.getEventMarkets(params); }
  getEventOrders(params?: any) { return this.eventWrapper.getEventOrders(params); }
  getEventOrder(params: any) { return this.eventWrapper.getEventOrder(params); }
  getEventOrderbook(params?: any) { return this.eventWrapper.getEventOrderbook(params); }
  getEventCandlesticks(params?: any) { return this.eventWrapper.getEventCandlesticks(params); }
  getEventFills(params?: any) { return this.eventWrapper.getEventFills(params); }
  getEventOrdersByEventId(eventId: string, params?: any) { return this.eventWrapper.getEventOrdersByEventId(eventId, params); }
  getEventOrderbookByEventId(eventId: string, params?: any) { return this.eventWrapper.getEventOrderbookByEventId(eventId, params); }
  getEventCandlesticksByEventId(eventId: string, params?: any) { return this.eventWrapper.getEventCandlesticksByEventId(eventId, params); }
  getEventFillsByEventId(eventId: string, params?: any) { return this.eventWrapper.getEventFillsByEventId(eventId, params); }
  
  // Collection methods
  getCollection(params?: any) { return this.collectionWrapper.getCollection(params); }
  getCollectionMarkets(params?: any) { return this.collectionWrapper.getCollectionMarkets(params); }
  getCollectionOrders(params?: any) { return this.collectionWrapper.getCollectionOrders(params); }
  getCollectionOrder(params: any) { return this.collectionWrapper.getCollectionOrder(params); }
  getCollectionOrderbook(params?: any) { return this.collectionWrapper.getCollectionOrderbook(params); }
  getCollectionCandlesticks(params?: any) { return this.collectionWrapper.getCollectionCandlesticks(params); }
  getCollectionFills(params?: any) { return this.collectionWrapper.getCollectionFills(params); }
  getCollectionOrdersByCollectionId(collectionId: string, params?: any) { return this.collectionWrapper.getCollectionOrdersByCollectionId(collectionId, params); }
  getCollectionOrderbookByCollectionId(collectionId: string, params?: any) { return this.collectionWrapper.getCollectionOrderbookByCollectionId(collectionId, params); }
  getCollectionCandlesticksByCollectionId(collectionId: string, params?: any) { return this.collectionWrapper.getCollectionCandlesticksByCollectionId(collectionId, params); }
  getCollectionFillsByCollectionId(collectionId: string, params?: any) { return this.collectionWrapper.getCollectionFillsByCollectionId(collectionId, params); }
  
  // Structured target methods
  getStructuredTarget(params?: any) { return this.structuredTargetWrapper.getStructuredTarget(params); }
  getStructuredTargetMarkets(params?: any) { return this.structuredTargetWrapper.getStructuredTargetMarkets(params); }
  getStructuredTargetOrders(params?: any) { return this.structuredTargetWrapper.getStructuredTargetOrders(params); }
  getStructuredTargetOrder(params: any) { return this.structuredTargetWrapper.getStructuredTargetOrder(params); }
  getStructuredTargetOrderbook(params?: any) { return this.structuredTargetWrapper.getStructuredTargetOrderbook(params); }
  getStructuredTargetCandlesticks(params?: any) { return this.structuredTargetWrapper.getStructuredTargetCandlesticks(params); }
  getStructuredTargetFills(params?: any) { return this.structuredTargetWrapper.getStructuredTargetFills(params); }
  getStructuredTargetOrdersByStructuredTargetId(structuredTargetId: string, params?: any) { return this.structuredTargetWrapper.getStructuredTargetOrdersByStructuredTargetId(structuredTargetId, params); }
  getStructuredTargetOrderbookByStructuredTargetId(structuredTargetId: string, params?: any) { return this.structuredTargetWrapper.getStructuredTargetOrderbookByStructuredTargetId(structuredTargetId, params); }
  getStructuredTargetCandlesticksByStructuredTargetId(structuredTargetId: string, params?: any) { return this.structuredTargetWrapper.getStructuredTargetCandlesticksByStructuredTargetId(structuredTargetId, params); }
  getStructuredTargetFillsByStructuredTargetId(structuredTargetId: string, params?: any) { return this.structuredTargetWrapper.getStructuredTargetFillsByStructuredTargetId(structuredTargetId, params); }
}

export { RATE_LIMIT_TIERS };
export type { RateLimitUsage, RateLimitTier };
