
import { KalshiApiClientBase } from '../KalshiApiClientBase';
import { 
  CollectionParams, 
  SelectedMarket, 
  CreateMarketInCollectionResponse,
  CollectionLookupHistoryResponse,
  LookupMarketInCollectionResponse 
} from '../types';

/**
 * Collection-related API client methods
 */
export class CollectionApiClient extends KalshiApiClientBase {
  // Collection methods
  getCollections(params?: CollectionParams) {
    return this.collectionFacade.getCollections(params);
  }
  
  getCollection(collectionTicker: string) {
    return this.collectionFacade.getCollection(collectionTicker);
  }
  
  createMarketInCollection(
    collectionTicker: string,
    selectedMarkets: SelectedMarket[]
  ): Promise<CreateMarketInCollectionResponse | null> {
    return this.collectionFacade.createMarketInCollection(collectionTicker, selectedMarkets);
  }

  getCollectionLookupHistory(
    collectionTicker: string, 
    lookbackSeconds: number
  ): Promise<CollectionLookupHistoryResponse | null> {
    return this.collectionFacade.getCollectionLookupHistory(collectionTicker, lookbackSeconds);
  }

  lookupMarketInCollection(
    collectionTicker: string,
    selectedMarkets: SelectedMarket[]
  ): Promise<LookupMarketInCollectionResponse | null> {
    return this.collectionFacade.lookupMarketInCollection(collectionTicker, selectedMarkets);
  }
}
