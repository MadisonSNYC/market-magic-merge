
import { KalshiApiClientBase } from '../KalshiApiClientBase';

/**
 * Event and Series-related API client methods
 */
export class EventApiClient extends KalshiApiClientBase {
  // Event methods
  getEvents(params?: {
    cursor?: string;
    limit?: number;
    status?: string;
    seriesTicker?: string;
    withNestedMarkets?: boolean;
  }) {
    return this.eventFacade.getEvents(params);
  }
  
  getAllEvents(params?: {
    cursor?: string;
    limit?: number;
    status?: string;
    seriesTicker?: string;
  }) {
    return this.eventFacade.getAllEvents(params);
  }
  
  getEventByTicker(eventTicker: string, withNestedMarkets: boolean = false) {
    return this.eventFacade.getEventByTicker(eventTicker, withNestedMarkets);
  }
  
  getEvent(eventTicker: string, withNestedMarkets: boolean = true) {
    return this.eventFacade.getEvent(eventTicker, withNestedMarkets);
  }
  
  // Series methods
  getSeries(seriesTicker: string) {
    return this.seriesFacade.getSeries(seriesTicker);
  }
  
  getAllSeries() {
    return this.seriesFacade.getAllSeries();
  }
}
