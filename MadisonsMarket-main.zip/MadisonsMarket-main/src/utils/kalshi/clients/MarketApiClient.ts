
import { KalshiApiClientBase } from '../KalshiApiClientBase';
import { CandlestickParams } from '../types';

/**
 * Market-related API client methods
 */
export class MarketApiClient extends KalshiApiClientBase {
  // Market methods
  getMarkets(params?: {
    limit?: number;
    cursor?: string;
    eventTicker?: string;
    seriesTicker?: string;
    maxCloseTs?: number;
    minCloseTs?: number;
    status?: string | string[];
    tickers?: string | string[];
  }) {
    return this.marketFacade.getMarkets(params);
  }
  
  getMarketById(id: string) {
    return this.marketFacade.getMarketById(id);
  }
  
  getMarketsByEvent(eventTicker: string) {
    return this.marketFacade.getMarketsByEvent(eventTicker);
  }
  
  getMarketsBySeries(seriesTicker: string) {
    return this.marketFacade.getMarketsBySeries(seriesTicker);
  }
  
  getMarket(ticker: string) {
    return this.marketFacade.getMarket(ticker);
  }
  
  getMarketOrderbook(ticker: string, depth?: number) {
    return this.marketFacade.getMarketOrderbook(ticker, depth);
  }
  
  getMarketCandlesticks(
    seriesTicker: string,
    ticker: string,
    params: CandlestickParams
  ) {
    return this.marketFacade.getMarketCandlesticks(seriesTicker, ticker, params);
  }
}
