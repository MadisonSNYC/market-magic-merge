
import { KalshiApiClientBase } from '../KalshiApiClientBase';
import { KalshiMilestoneParams } from '../types';

/**
 * Meta and Exchange-related API client methods
 */
export class MetaApiClient extends KalshiApiClientBase {
  // Meta methods
  getApiVersion() {
    return this.metaFacade.getApiVersion();
  }
  
  getCommunicationsId() {
    return this.metaFacade.getCommunicationsId();
  }
  
  // Exchange methods
  getExchangeAnnouncements() {
    return this.exchangeFacade.getAnnouncements();
  }
  
  getExchangeSchedule() {
    return this.exchangeFacade.getSchedule();
  }
  
  getExchangeStatus() {
    return this.exchangeFacade.getStatus();
  }
  
  getMilestones(params?: KalshiMilestoneParams) {
    return this.exchangeFacade.getMilestones(params);
  }
  
  getMilestoneById(milestoneId: string) {
    return this.exchangeFacade.getMilestoneById(milestoneId);
  }
}
