
import { KalshiCoreClient } from '../client/coreClient';
import { StructuredTarget } from '../types';
import { structuredTargetFacade } from '../facades/structuredTargetFacade';

export class StructuredTargetApiClient {
  private coreClient: KalshiCoreClient;
  private facade: typeof structuredTargetFacade;

  constructor(coreClient: KalshiCoreClient) {
    this.coreClient = coreClient;
    this.facade = structuredTargetFacade;
  }
  
  // Get a structured target by ID
  async getStructuredTarget(structuredTargetId: string): Promise<StructuredTarget | null> {
    try {
      return await this.facade.getStructuredTarget(this.coreClient, structuredTargetId);
    } catch (error) {
      console.error('Error getting structured target:', error);
      return null;
    }
  }
}
