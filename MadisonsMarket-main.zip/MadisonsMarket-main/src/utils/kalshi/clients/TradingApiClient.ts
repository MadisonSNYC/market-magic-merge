
import { KalshiApiClientBase } from '../KalshiApiClientBase';
import { TradeParams } from '../types';

/**
 * Trading-related API client methods (RFQ, Quote, Trade)
 */
export class TradingApiClient extends KalshiApiClientBase {
  // RFQ methods
  getRfqs(params?: any) {
    return this.rfqFacade.getRfqs(params);
  }
  
  getRfqById(rfqId: string) {
    return this.rfqFacade.getRfqById(rfqId);
  }
  
  createRfq(params: any) {
    return this.rfqFacade.createRfq(params);
  }
  
  deleteRfq(rfqId: string) {
    return this.rfqFacade.deleteRfq(rfqId);
  }
  
  // Quote methods
  getQuotes(params?: any) {
    return this.quoteFacade.getQuotes(params);
  }
  
  getQuoteById(quoteId: string) {
    return this.quoteFacade.getQuoteById(quoteId);
  }
  
  createQuote(params: any) {
    return this.quoteFacade.createQuote(params);
  }
  
  deleteQuote(quoteId: string) {
    return this.quoteFacade.deleteQuote(quoteId);
  }
  
  acceptQuote(quoteId: string, acceptedSide?: string) {
    return this.quoteFacade.acceptQuote(quoteId, acceptedSide);
  }
  
  confirmQuote(quoteId: string) {
    return this.quoteFacade.confirmQuote(quoteId);
  }
  
  // Trade methods
  getTrades(params?: TradeParams) {
    return this.tradeFacade.getTrades(params);
  }
  
  getTradesByMarket(marketId: string, params?: Omit<TradeParams, 'ticker'>) {
    return this.tradeFacade.getTradesByMarket(marketId, params);
  }
}
