import { KalshiApiClientBase } from '../KalshiApiClientBase';
import { 
  FillsParams, 
  KalshiOrder, 
  OrdersParams, 
  BatchCreateOrdersRequest, 
  BatchCancelOrdersRequest,
  AmendOrderRequest,
  DecreaseOrderRequest
} from '../types';

/**
 * User-related API client methods
 */
export class UserApiClient extends KalshiApiClientBase {
  // User methods
  getPositions() {
    return this.userFacade.getPositions();
  }
  
  placeOrder(order: any) {
    return this.userFacade.placeOrder(order);
  }
  
  getPortfolio() {
    return this.userFacade.getPortfolio();
  }
  
  getAiRecommendations() {
    return this.userFacade.getAiRecommendations();
  }

  getBalance() {
    return this.userFacade.getBalance();
  }

  getFills(params?: FillsParams) {
    return this.userFacade.getFills(params);
  }
  
  getOrders(params?: OrdersParams) {
    return this.userFacade.getOrders(params);
  }
  
  createOrder(order: KalshiOrder) {
    return this.userFacade.createOrder(order);
  }
  
  batchCreateOrders(batchRequest: BatchCreateOrdersRequest) {
    return this.userFacade.batchCreateOrders(batchRequest);
  }
  
  batchCancelOrders(batchRequest: BatchCancelOrdersRequest) {
    return this.userFacade.batchCancelOrders(batchRequest);
  }
  
  getOrder(orderId: string) {
    return this.userFacade.getOrder(orderId);
  }
  
  cancelOrder(orderId: string) {
    return this.userFacade.cancelOrder(orderId);
  }
  
  amendOrder(orderId: string, amendRequest: AmendOrderRequest) {
    return this.userFacade.amendOrder(orderId, amendRequest);
  }
  
  decreaseOrder(orderId: string, decreaseRequest: DecreaseOrderRequest) {
    return this.userFacade.decreaseOrder(orderId, decreaseRequest);
  }
  
  getTotalRestingOrderValue() {
    return this.userFacade.getTotalRestingOrderValue();
  }
}
