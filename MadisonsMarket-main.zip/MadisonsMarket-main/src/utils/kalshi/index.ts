// Export the kalshiApi for backward compatibility
export { kalshiApi, kalshiClient } from './kalshiApi';

// Re-export types from the original implementation for backward compatibility
export { KalshiMarket, KalshiPosition, KalshiOrder, KalshiPortfolioData } from './types';

// Export types from the new implementation
export * from './types/api-responses';
export * from './config';
export * from './client';
