
import { KalshiMarket, KalshiPortfolioData, Position, KalshiAiRecommendation } from '../types';
import { mockKalshiPositions, mockPositions } from './positions';
import { mockTrades, mockKalshiTrades } from './trades';
import { mockAiRecommendations } from './recommendations';
import { mockKalshiMarkets, marketCategories } from './markets';
import { portfolioData } from './portfolio';

// Export everything
export {
  marketCategories,
  mockKalshiMarkets,
  portfolioData,
  mockPositions,
  mockKalshiPositions,
  mockAiRecommendations,
  mockTrades,
  mockKalshiTrades
};
