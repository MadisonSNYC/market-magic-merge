
import { KalshiMarket } from '../types';

export const marketCategories = [
  'Crypto',
  'Politics',
  'Sports',
  'Weather',
  'Economics',
  'Entertainment',
  'Science'
];

export const mockKalshiMarkets: KalshiMarket[] = [
  {
    id: 'market-1',
    title: 'Bitcoin > $50K by April',
    subtitle: 'Will BTC exceed $50,000?',
    category: 'Crypto',
    status: 'open',
    closingTime: '2025-04-01T00:00:00Z',
    yes_price: 0.65,
    no_price: 0.35,
    volume: 10000,
    eventTicker: 'BTC-APR',
    seriesTicker: 'BTC-2025',
    ticker: 'BTC-50K-APR'
  },
  {
    id: 'market-2',
    title: 'Ethereum > $3K by May',
    subtitle: 'Will ETH exceed $3,000?',
    category: 'Crypto',
    status: 'open',
    closingTime: '2025-05-01T00:00:00Z',
    yes_price: 0.72,
    no_price: 0.28,
    volume: 8500,
    eventTicker: 'ETH-MAY',
    seriesTicker: 'ETH-2025',
    ticker: 'ETH-3K-MAY'
  },
  {
    id: 'market-3',
    title: 'Democrats win 2024 election',
    subtitle: 'Will Democrats win the 2024 presidential election?',
    category: 'Politics',
    status: 'open',
    closingTime: '2024-11-05T00:00:00Z',
    yes_price: 0.48,
    no_price: 0.52,
    volume: 25000,
    eventTicker: 'ELECTION-2024',
    seriesTicker: 'US-POLITICS',
    ticker: 'DEM-WIN-2024'
  }
];
