
import { KalshiPortfolioData } from '../types';

export const portfolioData: KalshiPortfolioData = {
  availableBalance: 10000,
  totalPortfolioValue: 12500,
  lastUpdated: new Date().toISOString()
};
