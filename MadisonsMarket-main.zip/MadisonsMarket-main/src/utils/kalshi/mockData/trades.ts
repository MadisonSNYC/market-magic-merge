
import { KalshiTrade } from '../types/trades';

export const mockTrades: KalshiTrade[] = [
  {
    id: 'trade-1',
    market_id: 'market-1',
    ticker: 'BTC-50K-APR',
    timestamp: '2023-10-15T14:30:00Z',
    price: 0.65,
    count: 10,
    side: 'yes',
    type: 'limit'
  },
  {
    id: 'trade-2',
    market_id: 'market-2',
    ticker: 'ETH-3K-MAY',
    timestamp: '2023-10-16T09:45:00Z',
    price: 0.72,
    count: 5,
    side: 'yes',
    type: 'limit'
  },
  {
    id: 'trade-3',
    market_id: 'market-3',
    ticker: 'DEM-WIN-2024',
    timestamp: '2023-10-18T16:20:00Z',
    price: 0.52,
    count: 8,
    side: 'no',
    type: 'market'
  }
];

// Add mock trades for backward compatibility
export const mockKalshiTrades: KalshiTrade[] = [
  {
    id: 'trade-1',
    market_id: 'market-1',
    ticker: 'BTC-50K-APR',
    timestamp: '2025-03-15T10:30:00Z',
    price: 0.65,
    count: 10,
    side: 'yes',
    type: 'limit'
  },
  {
    id: 'trade-2',
    market_id: 'market-2',
    ticker: 'ETH-3K-MAY',
    timestamp: '2025-03-16T14:45:00Z',
    price: 0.72,
    count: 5,
    side: 'yes',
    type: 'limit'
  }
];
