
// Common types used across the Kalshi API - Core types only
// Specific domain types are in their respective files

// Position in a market
export interface KalshiPosition {
  marketId: string;
  yes: number;
  no: number;
  value: number;
  title?: string;       // Add this property
  market_title?: string;
  expires_at?: string;
  expiration?: string;
  price?: number;
  cost?: number;
  payout?: number;
}

// AI Recommendation
export interface KalshiAiRecommendation {
  marketId: string;
  recommendation: string;
  reason: string;
  contractPrice: number;
  size: number;
  cost: number;
  potentialProfit: number;
  potentialPayout: number;
  confidence: number;
  category: string;
}

// Market data
export interface KalshiMarket {
  id: string;
  title: string;
  subtitle?: string;
  category: string;
  status: string;
  closingTime: string;
  yes_price: number;
  no_price: number;
  volume: number;
  eventTicker?: string;
  seriesTicker?: string;
  ticker?: string;      // Add this property
}

// API response structure
export interface KalshiApiResponse<T> {
  data: T;
  status: string;
  message?: string;
}

// Order data
export interface KalshiOrder {
  id?: string;          // Optional for creation
  marketId?: string;    // Optional for creation
  side: 'yes' | 'no';
  price?: number;
  yes_price?: number;
  no_price?: number;
  type?: string;
  size?: number;
  status?: 'open' | 'filled' | 'canceled';
  createdAt?: string;   // Optional for creation
  cost?: number;
  count?: number;       // Alternative to size
  ticker?: string;
  order_id?: string;    // Alternative to id
  client_order_id?: string;
  created_time?: string; // Alternative to createdAt
  updated_time?: string;
  filled_count?: number;
  remaining_count?: number;
}

// Portfolio data
export interface KalshiPortfolioData {
  availableBalance: number;
  totalPortfolioValue: number;
  lastUpdated: string;
}

// Selected market type
export interface SelectedMarket {
  id: string;
  value?: number;
  // Adding fields needed by the collections module
  event_ticker?: string;
  market_ticker?: string;
  side?: string;
}

// Re-export specific types to avoid ambiguity
export type { Position } from './types/portfolio';
export type { KalshiMarket as ExportedKalshiMarket } from './types/markets';
export type { KalshiPosition as ExportedKalshiPosition } from './types/portfolio';

// We don't directly export from these modules to avoid naming conflicts
// Instead, import specific types when needed
