
export interface KalshiApiVersionResponse {
  version: string;
}

export interface KalshiCommunicationsIdResponse {
  communications_id: string;
}
