import { KalshiTrade } from '../types';

export const mockKalshiTrades: KalshiTrade[] = [
  {
    id: 'trade-1',
    market_id: 'market-1',
    ticker: 'BTC-50K-APR',
    timestamp: '2025-03-15T10:30:00Z',
    price: 0.65,
    count: 10,
    side: 'yes',
    type: 'limit'
  },
  {
    id: 'trade-2',
    market_id: 'market-2',
    ticker: 'ETH-3K-MAY',
    timestamp: '2025-03-16T14:45:00Z',
    price: 0.72,
    count: 5,
    side: 'yes',
    type: 'limit'
  }
];
